         <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,400">
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Droid+Sans">
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lobster">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/animate.css">
        <link rel="stylesheet" href="/css/magnific-popup.css">
        <link rel="stylesheet" href="flexslider/flexslider.css">
        <link rel="stylesheet" href="css/form-elements.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/media-queries.css">

 <form role="form" action="autenticacion.php" method="post">
         <div class="form-group">
               <label for="contact-name">Nombre</label>
               <input type="text" name="usuario" placeholder="Tu Nombre..." class="contact-name" id="usuario">
         </div>
         <div class="form-group">
              <label for="password">Password</label>
              <input type="password" name="pw" placeholder="Tu contraseña..." class="contact-email" id="pw">
         </div>
         <button id="submit" name="login" class="btn btn-primary" style="width:100%;text-align:center;">Enviar</button>
</form>