       

        <!-- Footer -->
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-3 footer-box wow fadeInUp">
                        <h4>Acerca de</h4>
                        <div class="footer-box-text">
	                        <p>
	                        	Somos un grupo con el objetivo de lograr un trabajo correcto, nos destacamos por nuestra responsabilidad y puntualidad.
	                        </p>
	                       
                        </div>
                    </div>

                    <div class="col-sm-3 footer-box wow fadeInDown">
                       
                    </div>

                    <div class="col-sm-3 footer-box wow fadeInDown">
                        <h4>Contactanos</h4>
                        <div class="footer-box-text footer-box-text-contact">
	                        <p><i class="fa fa-map-marker"></i> Dirección: Juan florio 318</p>
	                        <p><i class="fa fa-phone"></i> Telefono:4659-6973</p>
	                        <p><i class="fa fa-user"></i> Horario: 09:00Hs a 18:00Hs</p>
	                        <p><i class="fa fa-envelope"></i> Email: <a href="">julianbermolen@gmail.com</a></p>
                        </div>
                    </div>
                </div>
                <div class="row">
                	<div class="col-sm-12 wow fadeIn">
                		<div class="footer-border"></div>
                	</div>
                </div>
                <div class="row">
                    <div class="col-sm-7 footer-copyright wow fadeIn">
                        <p> <a href="www.verdeazulado.com.ar">VerdeAzulado</a>.</p>
                    </div>
                    <div class="col-sm-5 footer-social wow fadeIn">
                        <a href="https://www.facebook.com/colecoconfeccion/"><i class="fa fa-facebook"></i></a>
                        
                    </div>
                </div>
            </div>
        </footer>

        <!-- Javascript -->
        <script src="assets/js/jquery-1.11.1.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/bootstrap-hover-dropdown.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/retina-1.1.0.min.js"></script>
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <script src="assets/flexslider/jquery.flexslider-min.js"></script>
        <script src="assets/js/jflickrfeed.min.js"></script>
        <script src="assets/js/masonry.pkgd.min.js"></script>
        <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
        <script src="assets/js/jquery.ui.map.min.js"></script>
        <script src="assets/js/scripts.js"></script>

    </body>

</html>